<?php
$host="localhost";
$username="root";
$password="";
$database="mapdownload";

$conn = mysqli_connect($host, $username, $password) or die(mysql_error());
mysqli_set_charset($conn,'utf8');
mysqli_select_db($conn,$database) or die(mysql_error());


?>