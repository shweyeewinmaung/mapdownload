<?php
require('pdf/fpdf.php');
$pdf=new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',10);
$pdf->Ln();
$pdf->Ln();
$pdf->SetFont('times','B',10);
$pdf->Cell(25,7,"confirm_code");
$pdf->Cell(30,7,"Name");
$pdf->Cell(40,7,"Email");
$pdf->Cell(30,7,"Phone");
$pdf->Cell(30,7,"Reason");
$pdf->Cell(30,7,"Wherefrom");
$pdf->Ln();
$pdf->Cell(450,7,"----------------------------------------------------------------------------------------------------------------------------------------------------------------------");
$pdf->Ln();

        include ('db.php');
        $sql = "SELECT * FROM temp";
        $result = mysqli_query($conn,$sql);

        while($rows=mysqli_fetch_array($result))
        {
            $confirm_code = $rows[0];
            $Name = $rows[1];
            $Email = $rows[2];
            $Phone = $rows[3];
            $Reason = $rows[4];
            $Wherefrom = $rows[5];
            $pdf->Cell(25,7,$confirm_code);
            $pdf->Cell(30,7,$Name);
            $pdf->Cell(40,7,$Email);
            $pdf->Cell(30,7,$Phone);
            $pdf->Cell(30,7,$Reason);
            $pdf->Cell(30,7,$Wherefrom); 
            $pdf->Ln(); 
        }
$pdf->Output();
?>