<?php

include("db.php");


    //$setSql = "SELECT * FROM temp order by Name desc";
	$setSql = "SELECT * FROM register order by ID desc";   
    $setRec = mysqli_query($conn, $setSql);  
    //mysqli_set_charset('utf8',$setRec);
	// mysqli_query("SET NAMES 'utf8'",$conn);
//mysql_query("SET CHARACTER SET utf8");
//mysql_query("SET COLLATION_CONNECTION = 'utf8_unicode_ci'");
	 
	 
    $columnHeader = '';  
    $columnHeader =   $columnHeader = "Sr NO" . "\t" . "Name" . "\t" . "Email" . "\t" ."Phone"."\t"  ."Reason" ."\t". "Wherefrom" ."\t". "Page" . "\t";    
      
    $setData = '';  
      
    while ($rec = mysqli_fetch_row($setRec)) {  
        $rowData = '';  
        foreach ($rec as $value) {  
            $value = '"' . $value . '"' . "\t";  
            $rowData .= $value;  
        }  
        $setData .= trim($rowData) . "\n";  
    }  
      
      
    header("Content-type: application/octet-stream");  
    header("Content-Disposition: attachment; filename=Download_Detail_Reoprt.csv");
	header('Content-Type: text/html; charset=UTF-8');

    header("Pragma: no-cache");  
    header("Expires: 0");  
      
    echo ucwords($columnHeader) . "\n" . $setData . "\n";  
      
    ?>  
