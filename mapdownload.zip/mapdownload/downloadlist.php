<?php
session_start();

include("db.php");


$ret=GetDownloadDataByDownload($conn);
$num=mysqli_num_rows($ret);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script type="text/javascript">
function printpage()
  {
  window.print()
  }
</script>
</head>

<body>
 <table id="download_data" class="table table-striped table-bordered dt-responsive nowrap" width="98%" cellspacing="0">
                         <thead>
                            <tr>
                                <th>No</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                               
                                <th>Reason</th>
                                <th>Where</th>
                                <th>Page</th>
                               
                            </tr>
                            </thead>
                            <tbody>
                             <?php  $u=1;
                                while($row=mysqli_fetch_array($ret)){	?>  
                            <tr>
                                <th><?php echo $u; ?></th>
                                <th><?php echo $row['Name']; ?></th>
                                <th><?php echo $row['Email']; ?></th>
                                <th><?php echo $row['Phone']; ?></th>
                              
                                <th><?php echo $row['Reason']; ?></th>
                                <th><?php echo $row['Wherefrom']; ?></th>
                                <th><?php echo $row['Page']; ?></th>
                                
                            </tr>
                           <?php $u=$u+1;  } ?> 
                           </tbody>
                     </table> 
                     <a href="export.php"> Export To Excel </a>
                      <a href="pdfexport.php"> Export To PDF </a>
                     <?php  echo "<input type=\"button\" value=\"Print this page\" onclick=\"printpage()\" />"; ?>
</body>
</html>
<?php
function GetDownloadDataByDownload($conn)
{
	$sql="SELECT * FROM temp order by Name desc";
	return mysqli_query($conn,$sql);
}
?>