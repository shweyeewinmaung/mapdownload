-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2018 at 07:28 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.0.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mapdownload`
--

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `ID` int(50) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Reason` varchar(255) NOT NULL,
  `Wherefrom` varchar(255) NOT NULL,
  `Page` varchar(50) NOT NULL,
  `Created_Date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`ID`, `Name`, `Email`, `Phone`, `Reason`, `Wherefrom`, `Page`, `Created_Date`) VALUES
(40, 'zanhtet', 'zanhtet@gmail.com', '87472612', 'trip', 'website', 'Pyinoolwin', '0000-00-00 00:00:00'),
(41, 'kyaw Soe kaing', 'kyawsoekhaing@gmail.com', '+6597316977', 'to know more detail', 'google', 'Pyinoolwin', '0000-00-00 00:00:00'),
(42, 'ZinnThu', 'michelcullen5@gmail.com', '09788241932', 'To know how many miles to travel', 'Wherefrom', 'Myanmar', '0000-00-00 00:00:00'),
(44, 'Han Myo Zaw', 'hanmyozaw2215@gmail.com', '09951046053', 'Learning', 'your adveristment', 'Mandalay', '0000-00-00 00:00:00'),
(45, 'Aung Kyaw Kyaw', 'aungkyawkyaw402@gmail.com', '09795787561', 'For Power Point Presentation', 'Google á€á€¼á€„á€¹ á€›á€½á€¬á€»á€á€„á€¹á€¸á€»á€–á€„á€¹á€·á€žá€­á€›á€½á€•á€«á€žá€Šá€¹', 'Magway', '0000-00-00 00:00:00'),
(46, 'Jon', 'jonathan.molson80@gmail.com', '0000', 'Tourist', 'Lonely planet', 'Bagan', '0000-00-00 00:00:00'),
(47, 'Phyo', 'pyae1778@gmail.com', '+66991250124', 'Need', 'Wherefrom', 'Myanmar', '0000-00-00 00:00:00'),
(48, 'Phyo', 'pyae1778@gmail.com', '+66991250124', 'á€œá€­á€¯á€¡á€•á€¹á€œá€­á€¯á‚”á€•á€«', 'Fb', 'Shan', '0000-00-00 00:00:00'),
(49, 'á€€á€­á€¯á€œá€á€¹', 'nn36792@gmail.com', '09258320141', 'á€…á€…á€¹á€±á€á€¼á¿á€™á€­á€³á‚•á€›á€­á€½á€±á€”á€›á€¬á€™á€ºá€¬á€¸á€žá€­á€œá€­á€¯á', 'Google á€á€¼á€„á€¹á‚á€½á€¬á€±á€á€¼á‚”á€±á€žá€¬á€±á¾á€€á€¬á€„á€¹á€·', 'Sittwe', '0000-00-00 00:00:00'),
(51, 'myo', 'myo.myint.tun@frontiir.net', '+959799797841', 'Learning', 'Yangon', 'Yangon', '0000-00-00 00:00:00'),
(52, 'PCM', 'pcmgao@gmail.com', '073 22680', 'want to visit', 'searching from google', 'Pyinmana', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `temp`
--

CREATE TABLE `temp` (
  `confirm_code` varchar(255) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Phone` int(50) NOT NULL,
  `Reason` varchar(255) NOT NULL,
  `Wherefrom` varchar(255) NOT NULL,
  `Page` varchar(50) NOT NULL,
  `Created_Date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Date` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `ID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
