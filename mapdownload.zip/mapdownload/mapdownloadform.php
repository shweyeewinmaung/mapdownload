<form method="post" action="downloadformaction.php">
													<input name="Name" placeholder="name  (အမည္)" type="text" required />
													<input name="Email" placeholder="email (အီးေမးလ္)" type="email" required />
													<input name="Phone" placeholder="phone (ဖုန္းနံပါတ္)" type="tel" required />
													<input name="Address" placeholder="Mailing Address (ေျမပံု ပို႕ေပးရမည့္သင့္စာတိုက္လိပ္စာ)" type="text" required />
													<input name="Reason" placeholder="reason for map download (ေျမပံု download ျပဳလုပ္ရသည့္အေၾကာင္းအရင္း)" type="text" required />
													<input name="Wherefrom" placeholder="where did you learn (ေျမပံု download လုပ္ရန္ဘယ္လုိသိပါသလဲ)" type="text" required />
													<p align="left" style="padding:0px 30px;">ယခု Form တြင္ျဖည့္ထားေသာ အခ်က္အလက္မ်ားအား DPS မွ ထိန္းသိမ္းထားမည္ျဖစ္ၿပီး လူႀကီးမင္းထံသို႔ DPS မွ သတင္းအခ်က္အလက္မ်ား ေပးပို႔ရန္အတြက္သာ အသံုးျပဳပါမည္။ အခ်က္အလက္မ်ားအား အျခားသူမ်ားအား မေပါက္ၾကားရန္ တာ၀န္ယူပါသည္။</p>
													<input value="Submit" class="formBtn" type="submit" name="btnMagway" />
													<input value="Reset" class="formBtn" type="reset" />
												</form>
                                                
                                              
                                              
                                              <form method="post" action="downloadformaction.php">
													<input name="Name" placeholder="name  (အမည္)" type="text" required />
													<input name="Email" placeholder="email (အီးေမးလ္)" type="email" required />
													<input name="Phone" placeholder="phone (ဖုန္းနံပါတ္)" type="tel" required />
													<input name="Address" placeholder="Mailing Address (ေျမပံု ပို႕ေပးရမည့္သင့္စာတိုက္လိပ္စာ)" type="text" required />
													<input name="Reason" placeholder="reason for map download (ေျမပံု download ျပဳလုပ္ရသည့္အေၾကာင္းအရင္း)" type="text" required />
													<input name="Wherefrom" placeholder="where did you learn (ေျမပံု download လုပ္ရန္ဘယ္လုိသိပါသလဲ)" type="text" required />
													<p align="left" style="padding:0px 30px;">ယခု Form တြင္ျဖည့္ထားေသာ အခ်က္အလက္မ်ားအား DPS မွ ထိန္းသိမ္းထားမည္ျဖစ္ၿပီး လူႀကီးမင္းထံသို႔ DPS မွ သတင္းအခ်က္အလက္မ်ား ေပးပို႔ရန္အတြက္သာ အသံုးျပဳပါမည္။ အခ်က္အလက္မ်ားအား အျခားသူမ်ားအား မေပါက္ၾကားရန္ တာ၀န္ယူပါသည္။</p>
													<input value="Submit" class="formBtn" type="submit" name="btnSaging" />
													<input value="Reset" class="formBtn" type="reset" />
												</form>