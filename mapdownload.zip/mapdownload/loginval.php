<?php
session_start();
include("../db.php");
include("../globalfunction.php");

$User_Name=Clean($conn,$_POST['User_Name']);
$User_Password=Clean($conn,$_POST['User_Password']);



if($User_Name == "dpsadmin" && $User_Password == "admin11181")
{
               $_SESSION['auth'] = true;
		
		header("location:index.php");
} 	
else
{
	//echo "<p style='color:red'>User name or password incorrect!",
				//"Please <a href='LogIn.php'>try again</a>.</p>";
 $_SESSION['auth'] = false;
header("location:LogIn.php");
}

?>